using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	public float speed;
	public float Delta;
	public GameObject LFoot;
	public GameObject RFoot;
	public Rigidbody rb;

	public bool IsMove;

	float Length2(Vector2 V) {
		return (float)Math.Sqrt(V.x * V.x + V.y * V.y);
	}

	float Length3(Vector3 V) {
		return (float)Math.Sqrt(V.x * V.x + V.z * V.z);
	}

	void Start() {
		IsMove = false;
	}

	void Update() {
		///Debug.Log("update");
		Vector3 movement = Vector3.zero;
		#if UNITY_ANDROID || UNITY_IOS

		#elif UNITY_STANDALONE
			//Debug.Log("standalone");
			float moveHorizontal = Input.GetAxis("Horizontal");
			float moveVertical = Input.GetAxis("Vertical");

			movement.x = moveHorizontal;
			movement.z = moveVertical;
		#endif
		if (movement != Vector3.zero) {
			IsMove = true;
		}
		else {
			IsMove = false;
		}
    movement *= speed;
		rb.AddForce(movement * 10);
		Vector3 NewPosition = transform.position;
		NewPosition.y = (LFoot.transform.position.y + RFoot.transform.position.y) / 2 + Delta - LFoot.transform.localScale.y / 2;
		transform.position = NewPosition;
		/*
		Vector3 NewPosition = transform.position + movement;
		NewPosition.y = (LFoot.transform.position.y + RFoot.transform.position.y) / 2 + Delta - LFoot.transform.localScale.y / 2;
    transform.position = NewPosition;
		*/

		//rb.AddForce(movement * speed);
		//transform.position += (Vector3)moveDirection * -10f * Time.deltaTime;
	}
}
