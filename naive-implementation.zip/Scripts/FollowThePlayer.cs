using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowThePlayer : MonoBehaviour {

	public GameObject Player;
	public float speed;

	private Vector3 delta;
	private Vector3 newdelta;
	private Vector3 movement;

    void Start() {
		delta =  Player.transform.position - transform.position;
    }

    void Update() {
		newdelta = Player.transform.position - transform.position;
		movement = newdelta - delta;
		movement *= speed * Time.deltaTime;
		transform.position = transform.position + movement;
    }
}
