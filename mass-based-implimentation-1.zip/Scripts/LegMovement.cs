using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LegMovement : MonoBehaviour
{
    private Vector3 vDown = new Vector3(0, -1f, 0);
    private Vector3 FootPosition;
    private Vector3 PrevFootPosition;

    private float[] StepLength;

    public GameObject Foot;
    public GameObject AnotherLeg;
    public GameObject FootBase;
    public GameObject Player;
    //public GameObject DebugSphere;

    //Const
    private const float EPS = 0.01f;
    private const float TimeToChangeStep = 0.3f;
    private const float RPos = 1f;
    private const float StepHeight = 0.3f;
    private const float CoMDelta = 0.3f;
    private const float StepLengthCoeff = 0.525f;
    private const float StepTime = 0.3f;
    // Const

    private int StepId;
    public string State;

    private float MoveTime;
    private float StandTime;

    private float CurTime;

    [SerializeField]
    private AnimationCurve curve;

    void Start() {
      State = "stand";
      StepId = 0;
      MoveTime = 0f;
      StandTime = 0f;
      CurTime = 0f;
      StepLength = new float[] {0.2f, 0.4f};
      Move();
    }


    // Update is called once per frame
    void Update()
    {
      CurTime = Mathf.Min(StepTime, CurTime + Time.deltaTime);
      if (State == "move" && CurTime == StepTime) {
        State = "stand";
      }

      if (State == "move" || State == "stand") {
        Vector3 CurPosition = PrevFootPosition + (FootPosition - PrevFootPosition) / StepTime * CurTime;
        CurPosition.y += curve.Evaluate(CurTime / StepTime) * StepHeight;
        Foot.transform.position = CurPosition;
      }
      else if (State == "free") {
        Vector3 CurPosition = PrevFootPosition + (FootPosition - PrevFootPosition) / StepTime * CurTime;
        Foot.transform.position = CurPosition;
      }

      if (Player.GetComponent<PlayerController>().IsMove) {
        StandTime = 0;
        MoveTime = Mathf.Min(MoveTime + Time.deltaTime, TimeToChangeStep);
      }
      else {
        MoveTime = 0;
        StandTime = Mathf.Min(StandTime + Time.deltaTime, TimeToChangeStep);
      }

      if (MoveTime == TimeToChangeStep) {
        MoveTime = 0;
        StepId = Mathf.Min(StepId + 1, 1);
      }
      if (StandTime == TimeToChangeStep) {
        StandTime = 0;
        StepId = Mathf.Max(StepId - 1, 0);
      }

      if (AnotherLeg.GetComponent<LegMovement>().State == "stand" && State == "stand") {
        if (NeedToMove() && !AnotherLeg.GetComponent<LegMovement>().NeedToMove()) {
          Move();
        }
        else if (NeedToMove() && AnotherLeg.GetComponent<LegMovement>().NeedToMove()) {
          if (DistanceToTarget() > AnotherLeg.GetComponent<LegMovement>().DistanceToTarget()) {
            Move();
          }
          else {
            //AnotherLeg.GetComponent<LegMovement>().Move();
          }
        }
      }
      else if (State == "free" || AnotherLeg.GetComponent<LegMovement>().State == "free") {
        Move();
      }

    }


    RaycastHit Raycast() {
      Ray ray;
      /*
      //Vector3 RayPosition = transform.position + Vector3.Normalize(transform.position - FootPosition) * (StepLength[StepId] - EPS);
      Vector3 RayPosition = transform.position;//FootPosition + 2 * (transform.position - FootPosition);
      Vector2 FootPosition2 = new Vector2(FootPosition.x, FootPosition.z);
      Vector2 FootBase2 = new Vector2(FootBase.transform.position.x, FootBase.transform.position.z);
      Vector2 RayPosition2 = new Vector2();
      RayPosition2 = FootBase2 + (FootBase2 - FootPosition2) / Vector2.Distance(FootBase2, FootPosition2) * (StepLength[StepId] - EPS);
      RayPosition.x = RayPosition2.x;
      RayPosition.z = RayPosition2.y;
      */
      /*
      Vector3 RayPosition = transform.position;
      Debug.Log(StepLength[StepId]);
      RayPosition += Vector3.Normalize(GameObject.Find("Player").GetComponent<Rigidbody>().velocity) * (StepLength[StepId] - EPS);
      //RayPosition.y = transform.position.y;

      ray = new Ray(RayPosition, vDown);
      RaycastHit hit;
      Physics.Raycast(ray, out hit, 2.0f);
      return hit;
      */
      /*
      Vector3 RayPosition = transform.position;
      RayPosition.x += Player.GetComponent<Rigidbody>().velocity.x * StepLengthCoeff;
      RayPosition.z += Player.GetComponent<Rigidbody>().velocity.z * StepLengthCoeff;
      ray = new Ray(RayPosition, vDown);
      RaycastHit hit;
      Physics.Raycast(ray, out hit, 2.0f);
      return hit;
      */
      Vector3 RayPosition = transform.position;
      //Vector3 velocity2 = Player.GetComponent<Rigidbody>().velocity;
      //velocity2.y = 0;
      //Vector3 BackVector = velocity2 * Mathf.Cos(Vector3.Angle(velocity2, transform.position - Foot.transform.position) * Mathf.PI / 360);

      RayPosition.x += Player.GetComponent<Rigidbody>().velocity.x * StepTime * 1.5f;
      RayPosition.z += Player.GetComponent<Rigidbody>().velocity.z * StepTime * 1.5f;
      //RayPosition -= BackVector;
      ray = new Ray(RayPosition, vDown);
      RaycastHit hit;
      Physics.Raycast(ray, out hit, 2.0f);
      return hit;
    }


    void Move() {
      RaycastHit hit = Raycast();
      if (hit.collider == null) {
        State = "free";
        PrevFootPosition = FootPosition;
        FootPosition = transform.position + vDown;
        CurTime = 0f;
      }
      else {
        State = "move";
        PrevFootPosition = FootPosition;
        FootPosition = hit.point;
        FootPosition.y += Foot.transform.localScale.y / 2;
        CurTime = 0f;
      }
    }

    bool NeedToMove() {
      if (State == "free") {
        return true;
      }
      Vector2 Player2 = new Vector2(Player.transform.position.x, Player.transform.position.z);
      Vector2 LFoot2 = new Vector2(FootPosition.x, FootPosition.z);
      Vector2 RFoot2 = new Vector2(AnotherLeg.GetComponent<LegMovement>().FootPosition.x, AnotherLeg.GetComponent<LegMovement>().FootPosition.z);
      return Vector2.Distance(LFoot2 - Player2 + RFoot2 - Player2, Vector2.zero) > CoMDelta;
      /// + correct NewPosition
    }
/*
    bool NeedToMove() {
      RaycastHit hit = Raycast();
      Vector3 TeorNewPosition = hit.point;
      TeorNewPosition.y += Foot.transform.localScale.y / 2;
      return (hit.collider != null && hit.collider.tag != "Player" && Vector3.Distance(FootBase.transform.position, FootPosition) >= StepLength[StepId]
                                                                   && Vector3.Distance(FootBase.transform.position, TeorNewPosition) < StepLength[StepId]);
    }
*/

    float DistanceToTarget() {
      RaycastHit hit = Raycast();
      return Vector3.Distance(hit.point, FootPosition);
    }


}
