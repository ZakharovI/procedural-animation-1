using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RaycastScript : MonoBehaviour
{
    private RaycastHit hit;
    private Vector3 vDown = new Vector3(0, -1, 0);
    private Ray ray;
    public GameObject sphere;
    private GameObject point;
    // Update is called once per frame

    void Start() {
      point = Instantiate(sphere, vDown, Quaternion.identity);
    }

    void Update()
    {
      ray = new Ray(transform.position, vDown);
      Physics.Raycast(ray, out hit, 2.0f);

      if (hit.collider != null && hit.collider.tag != "Player") {

        point.transform.position = hit.point;
      }
    }
}
