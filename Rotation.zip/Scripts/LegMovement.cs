using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LegMovement : MonoBehaviour
{
    private Vector3 FootPosition;
    private Vector3 PrevFootPosition;

    public GameObject Foot;
    public GameObject AnotherLeg;
    public GameObject FootBase;
    public GameObject Player;

    public string State;

    // Const
    private Vector3 vDown = new Vector3(0, -1f, 0);
    private const float TimeToChangeStep = 0.3f;
    private const float StepHeight = 0.3f;
    private const float StepTime = 0.3f;
    private const float CoMDelta = 0.3f;
    private const float TimeToSetNormalPosition = 0.1f;
    private const float StepCooldown = 0.2f;
    private const float DistanceToStablePosition = 0.1f;
    // Const

    private float StandTime;
    private float CurTime;
    private float TimeFromStep;

    [SerializeField]
    private AnimationCurve curve;


    void Start() {
      State = "stand";
      StandTime = 0f;
      CurTime = 0f;
      TimeFromStep = 0f;
      Move();
    }


    void Update()
    {
      TimeFromStep = Mathf.Max(0, TimeFromStep - Time.deltaTime);

      CurTime = Mathf.Min(StepTime, CurTime + Time.deltaTime);
      if (State == "move" && CurTime == StepTime) {
        State = "stand";
        TimeFromStep = StepCooldown;
      }

      if (State == "move" || State == "stand") {
        Vector3 CurPosition = PrevFootPosition + (FootPosition - PrevFootPosition) / StepTime * CurTime;
        CurPosition.y += curve.Evaluate(CurTime / StepTime) * StepHeight;
        Foot.transform.position = CurPosition;
      }
      else if (State == "free") {
        Vector3 CurPosition = PrevFootPosition + (FootPosition - PrevFootPosition) / StepTime * CurTime;
        Foot.transform.position = CurPosition;
      }

      if (Player.GetComponent<PlayerController>().IsMove) {
        StandTime = 0;
      }
      else if (StandTime < TimeToSetNormalPosition) {
        StandTime = Mathf.Min(StandTime + Time.deltaTime, TimeToSetNormalPosition);
        if (StandTime == TimeToSetNormalPosition) {

          ///----------------------------------------------------------------------------------------;
        }
      }

      if (AnotherLeg.GetComponent<LegMovement>().State == "stand" && State == "stand") {
        if (NeedToMove()) {
          if (AnotherLeg.GetComponent<LegMovement>().TimeFromStep != 0) {
            Move();
          }
          else if (AnotherLeg.GetComponent<LegMovement>().TimeFromStep == 0 && TimeFromStep == 0) {
            if (DistanceToTarget() > AnotherLeg.GetComponent<LegMovement>().DistanceToTarget()) {
              Move();
            }
          }
        }
        else if (UnstablePosition()) {
          if (TimeFromStep == 0) {
            Move();
          }
        }
      }
      else if (State == "free" || AnotherLeg.GetComponent<LegMovement>().State == "free") {
        Move();
      }
    }


    RaycastHit Raycast() {
      Ray ray;
      Vector3 RayPosition = transform.position;

      RayPosition.x += Player.GetComponent<Rigidbody>().velocity.x * StepTime * 1.5f;
      RayPosition.z += Player.GetComponent<Rigidbody>().velocity.z * StepTime * 1.5f;
      ray = new Ray(RayPosition, vDown);
      RaycastHit hit;
      Physics.Raycast(ray, out hit, 2.0f);
      return hit;
    }


    void Move() {
      RaycastHit hit = Raycast();
      if (hit.collider == null) {
        State = "free";
        PrevFootPosition = FootPosition;
        FootPosition = transform.position + vDown;
        CurTime = 0f;
      }
      else {
        State = "move";
        PrevFootPosition = FootPosition;
        FootPosition = hit.point;
        FootPosition.y += Foot.transform.localScale.y / 2;
        CurTime = 0f;
      }
    }


    bool NeedToMove() {
      if (State == "free") {
        return true;
      }
      Vector2 Player2 = new Vector2(Player.transform.position.x, Player.transform.position.z);
      Vector2 LFoot2 = new Vector2(FootPosition.x, FootPosition.z);
      Vector2 RFoot2 = new Vector2(AnotherLeg.GetComponent<LegMovement>().FootPosition.x, AnotherLeg.GetComponent<LegMovement>().FootPosition.z);
      return Vector2.Distance(LFoot2 - Player2 + RFoot2 - Player2, Vector2.zero) > CoMDelta;
      /// + correct NewPosition
    }


    bool UnstablePosition() {
      return Vector2.Distance(new Vector2(transform.position.x, transform.position.z), new Vector2(Foot.transform.position.x, Foot.transform.position.z)) > DistanceToStablePosition;
    }


    float DistanceToTarget() {
      RaycastHit hit = Raycast();
      return Vector3.Distance(hit.point, FootPosition);
    }
}
