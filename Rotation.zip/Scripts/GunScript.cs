using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunScript : MonoBehaviour
{
    public GameObject Bullet;
    private float TimeFromShoot;
    private const float ShootTime = 1f;

    void Start() {
      TimeFromShoot = 0f;
    }

    void Update()
    {
      TimeFromShoot += Time.deltaTime;
      if (Input.GetKeyDown(KeyCode.Space) || TimeFromShoot >= ShootTime) {
        GameObject NewBullet = (GameObject) Instantiate(Bullet, transform.position, transform.rotation);
        NewBullet.GetComponent<Rigidbody>().AddForce(new Vector3(0, 0, 10));
        TimeFromShoot = 0f;
      }
    }
}
