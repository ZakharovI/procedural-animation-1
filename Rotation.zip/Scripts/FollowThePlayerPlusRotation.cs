using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowThePlayerPlusRotation : MonoBehaviour {

	public GameObject Player;
  public Rigidbody rb;
	public float speed;

	private Vector3 delta;
	private Vector3 newdelta;
	private Vector3 movement;

  void Start() {
	  delta =  Player.transform.position - transform.position;
  }

  void Update() {
		newdelta = Player.transform.position - transform.position;
		movement = newdelta - delta;
		movement *= speed * Time.deltaTime;
    transform.position = transform.position + movement;
    transform.Rotate(new Vector3(0, transform.localEulerAngles.y * Time.deltaTime, 0));
  }
}
