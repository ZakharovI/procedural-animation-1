using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	public GameObject LFoot;
	public GameObject RFoot;
	public GameObject LLegBase;
	public GameObject RLegBase;
	//public GameObject DebugSphere;
	public Rigidbody rb;

	public bool IsMove;

	// Const
	private const float Speed = 1f;
	private const float RotationSpeed = 1.5f;
	private const float CoeffToCoMXZ = 1f;
	private const float CoeffToCoMY = 5f;
	private const float CoMDelta = 0.3f;
	private const float Delta = 1.25f;
	private const float G = 9.81f;
	private const float RadianToDegree = Mathf.PI * 2 / 360;
	private Vector3 Gforce = new Vector3(0, -9.81f, 0);
	// Const

	float Length2(Vector2 V) {
		return (float)Math.Sqrt(V.x * V.x + V.y * V.y);
	}

	float Length3(Vector3 V) {
		return (float)Math.Sqrt(V.x * V.x + V.z * V.z);
	}

	void Start() {
		Gforce *= 2;
		IsMove = false;
	}

	void Update() {
		///Debug.Log("update");
		Vector3 movement = Vector3.zero;
		Vector3 rotation = Vector3.zero;
		#if UNITY_ANDROID || UNITY_IOS

		#elif UNITY_STANDALONE
			//Debug.Log("standalone");
			float moveHorizontal = Input.GetAxis("Horizontal");
			float moveVertical = Input.GetAxis("Vertical");

			//movement.x = moveHorizontal;
			movement.z = moveVertical * Mathf.Cos(transform.localEulerAngles.y * RadianToDegree);
			movement.x = moveVertical * Mathf.Sin(transform.localEulerAngles.y * RadianToDegree);
			rotation.y = moveHorizontal;
		#endif

		if (movement != Vector3.zero) {
			IsMove = true;
		}
		else {
			IsMove = false;
		}
		/*
    movement *= speed;
		rb.AddForce(movement * 10);
		Vector3 NewPosition = transform.position;
		NewPosition.y = (LFoot.transform.position.y + RFoot.transform.position.y) / 2 + Delta - LFoot.transform.localScale.y / 2;
		transform.position = NewPosition;
		*/

		movement *= Speed;
		rotation *= RotationSpeed;
		//movement.y = ((LFoot.transform.position.y + RFoot.transform.position.y) / 2 + Delta - transform.position.y) * Coeff;

		Vector3 CoM = (LFoot.transform.position + RFoot.transform.position) / 2;
		CoM.y += Delta;
		//CoM.y = Mathf.Min(LFoot.transform.position.y, RFoot.transform.position.y) + Delta;
		//DebugSphere.transform.position = CoM;

		Vector3 ForceToCoM = (CoM - transform.position);
		if (Vector3.Distance(ForceToCoM, Vector3.zero) > CoMDelta) {
			ForceToCoM = ForceToCoM / Vector3.Distance(ForceToCoM, Vector3.zero) * CoMDelta;
		}
		ForceToCoM.x *= CoeffToCoMXZ;
		ForceToCoM.z *= CoeffToCoMXZ;
		ForceToCoM.y *= CoeffToCoMY;

		movement += ForceToCoM;
		//Vector3 CoM = new Vector3((LFoot.transform.position.x + RFoot.transform.position.x) / 2, (LFoot.transform.position.y + RFoot.transform.position.y) / 2 + Delta , (LFoot.transform.position.z + RFoot.transform.position.z) / 2);
		rb.AddForce(movement);
		UpdateAngularForce();
		transform.Rotate(rotation);

		/*
		Vector3 NewPosition = transform.position + movement;
		NewPosition.y = (LFoot.transform.position.y + RFoot.transform.position.y) / 2 + Delta - LFoot.transform.localScale.y / 2;
    transform.position = NewPosition;
		*/

		//rb.AddForce(movement * speed);
		//transform.position += (Vector3)moveDirection * -10f * Time.deltaTime;
	}

	void UpdateAngularForce() {
		if (LLegBase.GetComponent<LegMovement>().State == "free" && RLegBase.GetComponent<LegMovement>().State == "free") {
			rb.AddForce(Gforce * rb.mass);
		}
		else if (LLegBase.GetComponent<LegMovement>().State == "stand" && RLegBase.GetComponent<LegMovement>().State != "stand") {
			//Debug.Log("R");
			rb.AddForce(Mathf.Sin(Vector3.Angle(LFoot.transform.position - transform.position, Gforce) * Mathf.PI / 360) * Gforce * rb.mass);
		}
		else if (LLegBase.GetComponent<LegMovement>().State != "stand" && RLegBase.GetComponent<LegMovement>().State == "stand") {
			//Debug.Log("L");
			rb.AddForce(Mathf.Sin(Vector3.Angle(RFoot.transform.position - transform.position, Gforce) * Mathf.PI / 360) * Gforce * rb.mass);
		}
	}
}
