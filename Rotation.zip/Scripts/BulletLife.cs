using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletLife : MonoBehaviour
{
    private const float LifeTime = 1f;
    private float CurTime;

    void Start()
    {
      CurTime = 0f;
    }

    // Update is called once per frame
    void Update()
    {
      CurTime += Time.deltaTime;
      if (CurTime >= LifeTime) {
        Destroy(gameObject);
      }
    }
}
